# kumkum sharma

Simple webpage crafted using pure HTML and CSS. A minimalistic showcase of structure and design.



## Features



To switch between these themes, link the desired theme's CSS file in your HTML. For example, to use the Red Theme:

```html
<link rel="stylesheet" href="path/to/style-two.css" />
```

#### Authors:

- Special thanks to [Mr. Anbuselvan
  Rocky]() for his valuable mentorship.

##### Connect with me on:

-
